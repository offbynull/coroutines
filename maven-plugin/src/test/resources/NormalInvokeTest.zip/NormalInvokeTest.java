import com.offbynull.coroutines.user.Continuation;
import com.offbynull.coroutines.user.Coroutine;

public class NormalInvokeTest implements Coroutine {
    private StringBuilder builder;
    
    public NormalInvokeTest(StringBuilder builder) {
	this.builder = builder;
    }

    public void run(Continuation c) {
	builder.append("started\n");
	for (int i = 0; i < 10; i++) {
	    echo(c, i);
	}
    }

    private void echo(Continuation c, int x) {
	builder.append(x).append('\n');
	c.suspend();
    }
}
