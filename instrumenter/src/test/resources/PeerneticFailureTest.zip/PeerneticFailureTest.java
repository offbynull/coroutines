import java.util.concurrent.CountDownLatch;

import com.offbynull.coroutines.user.Continuation;
import com.offbynull.coroutines.user.Coroutine;
import com.offbynull.coroutines.user.CoroutineRunner;

public class PeerneticFailureTest 	{
    
    public static void main(String[] args) throws Exception {
        final CountDownLatch latch = new CountDownLatch(10);
        Coroutine coroutine = new Coroutine() {

            @Override
            public void run(Continuation c) throws Exception {
                System.out.println("1");
                Context context = (Context) c.getContext();

                Endpoint selfEp = (Endpoint) context.getMessage();
                c.suspend();
                System.out.println("2");
                Endpoint dstEp = (Endpoint) context.getMessage();

                for (int i = 0; i < 10; i++) {
                    dstEp.send(selfEp, i);
                    System.out.println("3");
                    c.suspend();
                    System.out.println("i currently is " + i);
//                Validate.isTrue(context.getMessage().equals(i));
//                try {
//                    latch.countDown();
//                } catch (Exception e) {
//                    System.out.println("lolwat?");
//                }
//                System.out.println("5");
                }
            }
        };
        
        Context context = new Context();
        CoroutineRunner runner = new CoroutineRunner(coroutine);
        runner.setContext(context);

        runner.execute();
        runner.execute();

        runner.execute();
        runner.execute();
        runner.execute();
        runner.execute();	
    }

    private static final class Endpoint {

	public void send(Endpoint selfEp, int i) {
	    // TODO Auto-generated method stub

	}

    }

    private static final class Context {

	public Endpoint getMessage() {
	    // TODO Auto-generated method stub
	    return new Endpoint();
	}

    }
}
