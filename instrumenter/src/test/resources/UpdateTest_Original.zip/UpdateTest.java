import com.offbynull.coroutines.user.Continuation;
import com.offbynull.coroutines.user.Coroutine;

public class UpdateTest implements Coroutine {
	private static final long serialVersionUID = 1L;

    public StringBuilder sb = new StringBuilder();

    @Override
    public void run(Continuation c) {
    	String mark = ".";
        sb.append(mark);
        echo(c, "hi");
        sb.append(mark);
    }

    private void echo(Continuation c, String input) {
        c.suspend();
        sb.append(input);
    }
}