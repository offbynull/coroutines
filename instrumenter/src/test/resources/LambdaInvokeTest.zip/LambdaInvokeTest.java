import java.util.function.Consumer;

import com.offbynull.coroutines.user.Continuation;
import com.offbynull.coroutines.user.Coroutine;

public class LambdaInvokeTest implements Coroutine {
    private StringBuilder builder;

    public LambdaInvokeTest(StringBuilder builder) {
	this.builder = builder;
    }

    public void run(Continuation c) {
	String temp = "hi";
	builder.append("started\n");
	for (int i = 0; i < 10; i++) {
	    Consumer<Integer> consumer = (x) -> {
		temp.length(); // pulls in temp as an arg, which causes c (the Continuation object) to go in as a the second argument  
		builder.append(x).append('\n');
		System.out.println("XXXXXXX");
		c.suspend();
	    };
	    consumer.accept(i);
	}
    }
}
