import com.offbynull.coroutines.user.Continuation;
import com.offbynull.coroutines.user.Coroutine;

public class ExceptionThenContinueInvokeTest implements Coroutine {

    private RuntimeException expectedException = new RuntimeException("Expected Exception!");
    public void run(Continuation c) {

	try {
	    new InnerClass1().run(c);
	} catch (RuntimeException re) {
	    /* Because we aren't unwinding method states after an exception occurs / is caught,
	       this block gets invoked once when InnerClass1.run() is called AND when
	       innerClass2().run() is called!
	      
	       Without proper unwinding, this is what's output by this test...

                in1 -- suspend InnerClass1
                in1 -- throwing exception InnerClass1
                Caught exception and continuing java.lang.RuntimeException: Expected Exception!
                in2 -- suspend InnerClass2
                Caught exception and continuing java.lang.RuntimeException: Unrecognized restore idrun
                Tests run: 1, Failures: 0, Errors: 1, Skipped: 0, Time elapsed: 2.694 sec <<< FAILURE!
                
                com.offbynull.coroutines.user.CoroutineException: Exception thrown during execution
                	at com.offbynull.coroutines.user.CoroutineRunner.execute(CoroutineRunner.java:57)
                	at com.offbynull.coroutines.instrumenter.InstrumenterTest.mustProperlyContinueWhenExceptionOccursButIsCaughtBeforeReachingRunner(InstrumenterTest.java:123)
                	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
                	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
                	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
                	at java.lang.reflect.Method.invoke(Method.java:483)
                	at org.junit.runners.model.FrameworkMethod$1.runReflectiveCall(FrameworkMethod.java:50)
                	at org.junit.internal.runners.model.ReflectiveCallable.run(ReflectiveCallable.java:12)
                	at org.junit.runners.model.FrameworkMethod.invokeExplosively(FrameworkMethod.java:47)
                	at org.junit.internal.runners.statements.InvokeMethod.evaluate(InvokeMethod.java:17)
                	at org.junit.rules.ExpectedException$ExpectedExceptionStatement.evaluate(ExpectedException.java:239)
                	at org.junit.rules.RunRules.evaluate(RunRules.java:20)
                	at org.junit.runners.ParentRunner.runLeaf(ParentRunner.java:325)
                	at org.junit.runners.BlockJUnit4ClassRunner.runChild(BlockJUnit4ClassRunner.java:78)
                	at org.junit.runners.BlockJUnit4ClassRunner.runChild(BlockJUnit4ClassRunner.java:57)
                	at org.junit.runners.ParentRunner$3.run(ParentRunner.java:290)
                	at org.junit.runners.ParentRunner$1.schedule(ParentRunner.java:71)
                	at org.junit.runners.ParentRunner.runChildren(ParentRunner.java:288)
                	at org.junit.runners.ParentRunner.access$000(ParentRunner.java:58)
                	at org.junit.runners.ParentRunner$2.evaluate(ParentRunner.java:268)
                	at org.junit.runners.ParentRunner.run(ParentRunner.java:363)
                	at org.apache.maven.surefire.junit4.JUnit4TestSet.execute(JUnit4TestSet.java:45)
                	at org.apache.maven.surefire.junit4.JUnit4Provider.executeTestSet(JUnit4Provider.java:123)
                	at org.apache.maven.surefire.junit4.JUnit4Provider.invoke(JUnit4Provider.java:104)
                	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
                	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
                	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
                	at java.lang.reflect.Method.invoke(Method.java:483)
                	at org.apache.maven.surefire.util.ReflectionUtils.invokeMethodWithArray(ReflectionUtils.java:164)
                	at org.apache.maven.surefire.booter.ProviderFactory$ProviderProxy.invoke(ProviderFactory.java:110)
                	at org.apache.maven.surefire.booter.SurefireStarter.invokeProvider(SurefireStarter.java:175)
                	at org.apache.maven.surefire.booter.SurefireStarter.runSuitesInProcessWhenForked(SurefireStarter.java:107)
                	at org.apache.maven.surefire.booter.ForkedBooter.main(ForkedBooter.java:68)
                Caused by: java.lang.RuntimeException: FAILED!
                	at ExceptionThenContinueInvokeTest.run(ExceptionThenContinueInvokeTest.java:17)
                	at com.offbynull.coroutines.user.CoroutineRunner.execute(CoroutineRunner.java:54)
                	... 32 more
                Caused by: java.lang.RuntimeException: Unrecognized restore idrun
                	at ExceptionThenContinueInvokeTest$InnerClass1.run(ExceptionThenContinueInvokeTest.java)
                	at ExceptionThenContinueInvokeTest.run(ExceptionThenContinueInvokeTest.java:10)
                	... 33 more
            */
	    
	    System.out.println("Caught exception and continuing " + re);
	    if (re != expectedException) {
		throw new RuntimeException("FAILED!", re);
	    }
	}
	
	new InnerClass2().run(c);
    }

    private final class InnerClass1 {
	public void run(Continuation c) {
	    System.out.println("in1 -- suspend " + getClass().getSimpleName());
	    c.suspend();
	    System.out.println("in1 -- throwing exception " + getClass().getSimpleName());
	    throw expectedException;
	}
    }

    private static final class InnerClass2 {
	public void run(Continuation c) {
	    System.out.println("in2 -- suspend " + getClass().getSimpleName());
	    c.suspend();
	    System.out.println("in2 -- return " + getClass().getSimpleName());
	}
    }
}
