import com.offbynull.coroutines.user.Continuation;
import com.offbynull.coroutines.user.Coroutine;

public class ExceptionThenContinueInvokeTest implements Coroutine {
    private StringBuilder builder;
    
    public ExceptionThenContinueInvokeTest(StringBuilder builder) {
	this.builder = builder;
    }

    public void run(Continuation c) {
	builder.append("started\n");
	for (int i = 0; i < 10; i++) {
	    try {
		echo(c, (byte) i, (char) i, (short) i, i, (long) i, (float) i, (double) i, i);
	    } catch (RuntimeException re) {
		System.out.print("Caught exception and continuing");
	    }
	}
    }

    private void echo(Continuation c, byte b, char ch, short s, int i, long l, float f, double d, Object o) {
	new InnerClass1().run(c);
	builder.append(i).append('\n');
	System.out.print(b);
	System.out.print(ch);
	System.out.print(s);
	System.out.print(i);
	System.out.print(l);
	System.out.print(f);
	System.out.print(d);
	System.out.println(o);
	c.suspend();
	System.out.print(b);
	System.out.print(ch);
	System.out.print(s);
	System.out.print(i);
	System.out.print(l);
	System.out.print(f);
	System.out.print(d);
	System.out.println(o);
	new InnerClass2().run(c);
    }
    
    private static final class InnerClass1 {
	public void run(Continuation cnt) {
	    System.out.println("in1 -- doing nothing");
	}
    }

    private static final class InnerClass2 {
	public void run(Continuation cnt) {
	    System.out.println("in2 -- throwing exception");
	    throw new RuntimeException();
	}
    }
}
