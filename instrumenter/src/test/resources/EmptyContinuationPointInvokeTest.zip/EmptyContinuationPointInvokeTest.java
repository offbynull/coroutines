import com.offbynull.coroutines.user.Continuation;
import com.offbynull.coroutines.user.Coroutine;

public class EmptyContinuationPointInvokeTest implements Coroutine {
    private StringBuilder builder;
    
    public EmptyContinuationPointInvokeTest(StringBuilder builder) {
	this.builder = builder;
    }

    public void run(Continuation c) {
	builder.append("started\n");
	for (int i = 0; i < 10; i++) {
	    echo(c, i);
	}
    }

    private void echo(Continuation c, int x) {
	doNothingContinuationPoint(c);
	builder.append(x).append('\n');
	c.suspend();
    }
    
    private void doNothingContinuationPoint(Continuation c) {
	System.out.println("CONTINUATION POINT THAT DOES NOTHING!");
    }
}
