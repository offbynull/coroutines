
public class SimpleStub {
    public void fillMeIn() {
    }
}
