import com.offbynull.coroutines.user.Continuation;
import com.offbynull.coroutines.user.Coroutine;

public class StaticInvokeTest implements Coroutine {
    private StringBuilder builder;
    
    public StaticInvokeTest(StringBuilder builder) {
	this.builder = builder;
    }

    public void run(Continuation c) {
	builder.append("started\n");
	for (int i = 0; i < 10; i++) {
	    echo(c, i, builder);
	}
    }

    private static void echo(Continuation c, int x, StringBuilder builder) {
	builder.append(x).append('\n');
	c.suspend();
    }
}
