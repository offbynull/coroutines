import com.offbynull.coroutines.user.Continuation;
import com.offbynull.coroutines.user.Coroutine;

public class JsrExceptionSuspendTest implements Coroutine {
    private StringBuffer builder;
    
    public JsrExceptionSuspendTest(StringBuffer builder) {
	this.builder = builder;
    }

    public void run(Continuation c) {
	innerTryCatchFinally(c);
    }

    private void innerTryCatchFinally(Continuation c) {
	builder.append("START").append('\n');
	try {
	    builder.append("IN TRY 1").append('\n');
	    c.suspend();
	    builder.append("IN TRY 2").append('\n');
	    throw new RuntimeException("exc");
	} catch (RuntimeException e) {
	    builder.append("IN CATCH 1").append('\n');
	    c.suspend();
	    builder.append("IN CATCH 2").append('\n');
	} finally {
	    builder.append("IN FINALLY 1").append('\n');
	    c.suspend();
	    builder.append("IN FINALLY 2").append('\n');
	}
	builder.append("END").append('\n');
    }
}