import com.offbynull.coroutines.user.Continuation;
import com.offbynull.coroutines.user.Coroutine;

public class ConstructorInvokeTest implements Coroutine {
    
    public ConstructorInvokeTest(Continuation c) {
    }

    public void run(Continuation c) {
	// does nothing
    }
}
