import com.offbynull.coroutines.user.Continuation;
import com.offbynull.coroutines.user.Coroutine;

public class DoubleReturnInvokeTest implements Coroutine {
    private StringBuilder builder;
    
    public DoubleReturnInvokeTest(StringBuilder builder) {
	this.builder = builder;
    }

    public void run(Continuation c) {
	builder.append("started\n");
	double i = 0;
	while (true) {
	    double res = echo(c, i);
	    if (res != (5.0 + i + (i * i))) {
		throw new RuntimeException("test failed!");
	    }
	    i++;
	    if (i >= 10L) {
		break;
	    }
	}
    }

    private double echo(Continuation c, double x) {
	return 5 + echoInner(c, x) + x;
    }
    
    private double echoInner(Continuation c, double x) {
	builder.append(x).append('\n');
	c.suspend();
	return x * x;
    }
}
