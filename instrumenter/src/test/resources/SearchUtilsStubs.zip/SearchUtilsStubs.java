import java.util.List;


public class SearchUtilsStubs {
    public void method1(int a, List b, double c) {
	
    }
    
    public void method2(int a, List b, String c) {
	
    }
    
    public void syncTest(Object obj) {
		synchronized(obj) {
		    System.out.println("test");
		}
    }

    public void localVariablesTest() {
    	Object val1 = 0;
		if (val1.equals(0)) {
			String val2 = "test";
		    System.out.println(val2);
		}
    }
}