import java.util.List;


public class SearchUtilsStubs {
    public void method1(int a, List b, double c) {
	
    }
    
    public void method2(int a, List b, String c) {
	
    }
    
    public void syncTest(Object obj) {
	synchronized(obj) {
	    System.out.println("test");
	}
    }
}
