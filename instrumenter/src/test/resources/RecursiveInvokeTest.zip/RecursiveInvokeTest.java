import com.offbynull.coroutines.user.Continuation;
import com.offbynull.coroutines.user.Coroutine;

public class RecursiveInvokeTest implements Coroutine {
    private StringBuilder builder;
    
    public RecursiveInvokeTest(StringBuilder builder) {
	this.builder = builder;
    }

    public void run(Continuation c) {
	builder.append("started\n");
	start(c, 0);
    }

    private void start(Continuation c, int x) {
	if (x == 10) {
	    return;
	}
	
	builder.append(x).append('\n');
	c.suspend();
	start(c, x + 1);
    }
}
