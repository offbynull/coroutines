
import com.offbynull.coroutines.user.Continuation;
import com.offbynull.coroutines.user.Coroutine;

public class InterceptTest implements Coroutine {

    public String name = InterceptTest.class.getSimpleName();
    public StringBuilder sb = new StringBuilder();

    public void run(Continuation c) {
        byte _b = 1;
        char _c = 2;
        int _i = 3;
        float _f = 4.0f;
        long _l = 5L;
        double _d = 6.0;
        String _s = "src";

        sb.append("pre_src:")
                .append(' ').append(name)
                .append(' ').append(_b)
                .append(' ').append(_c)
                .append(' ').append(_i)
                .append(' ').append(_f)
                .append(' ').append(_l)
                .append(' ').append(_d)
                .append(' ').append(_s)
                .append('\n');

        c.suspend();

        sb.append("post_src:")
                .append(' ').append(name)
                .append(' ').append(_b)
                .append(' ').append(_c)
                .append(' ').append(_i)
                .append(' ').append(_f)
                .append(' ').append(_l)
                .append(' ').append(_d)
                .append(' ').append(_s)
                .append('\n');
    }
}
