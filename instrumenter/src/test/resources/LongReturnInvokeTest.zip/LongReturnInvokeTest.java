import com.offbynull.coroutines.user.Continuation;
import com.offbynull.coroutines.user.Coroutine;

public class LongReturnInvokeTest implements Coroutine {
    private StringBuilder builder;
    
    public LongReturnInvokeTest(StringBuilder builder) {
	this.builder = builder;
    }

    public void run(Continuation c) {
	builder.append("started\n");
	long i = 0;
	while (true) {
	    long res = echo(c, i);
	    if (res != (5L + i + (i * i))) {
		throw new RuntimeException("test failed!");
	    }
	    i++;
	    if (i == 10L) {
		break;
	    }
	}
    }

    private long echo(Continuation c, long x) {
	return 5 + echoInner(c, x) + x;
    }
    
    private long echoInner(Continuation c, long x) {
	builder.append(x).append('\n');
	c.suspend();
	return x * x;
    }
}
