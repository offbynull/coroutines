import com.offbynull.coroutines.user.Continuation;
import com.offbynull.coroutines.user.Coroutine;

public class ComplexTest implements Coroutine {
    private static final Object LOCK1 = new Object();
    private static final Object LOCK2 = new Object();
    private StringBuilder builder;

    public ComplexTest(StringBuilder builder) {
	this.builder = builder;
    }

    public void run(Continuation c) {
	builder.append("started\n");
	int i = 0;
	while (true) {
	    int res = calcProxy(c, this, i);
	    if (res != (5 + i + (i * i))) {
		throw new RuntimeException("test failed!");
	    }
	    i++;
	    if (i == 10) {
		break;
	    }
	}
    }

    private static int calcProxy(Continuation c, ComplexTest ct, int x) {
	try {
	    return ct.calc(c, x);
	} catch (Exception e) {
	    ct.builder.append(x).append('\n');
	    synchronized (LOCK1) {
		c.suspend();
		synchronized (LOCK2) {
		    return 5 + (x * x) + x;
		}
	    }
	}
    }

    private int calc(Continuation c, int x) {
	synchronized (LOCK1) {
	    return 5 + pow2(c, x) + x;
	}
    }

    private int pow2(Continuation c, int x) {
	synchronized (LOCK1) {
	    synchronized (LOCK2) {
		if (x == 9) {
		    throw new RuntimeException();
		}
		builder.append(x).append('\n');
		c.suspend();
		return x * x;
	    }
	}
    }
}
