import com.offbynull.coroutines.user.Continuation;
import com.offbynull.coroutines.user.Coroutine;

public class SanityTest implements Coroutine {
    private StringBuilder builder;
    
    public SanityTest(StringBuilder builder) {
        this.builder = builder;
    }

    public void run(Continuation c) {
        builder.append("a");
        c.suspend();
        builder.append("b");
    }
}