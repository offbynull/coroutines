
import com.offbynull.coroutines.user.*;

import java.util.*;

public class Issue84Test implements Coroutine {

    public boolean allInstrum = false; // MUST BE PUBLIC

    public void run(Continuation c) {
        final String tag = new String("run()");
        if (!allInstrum) {
            final Long i = echo();
            System.out.println(i);
        } else {
            final List<Integer> i = echo(c, 1);
            System.out.println(i);
        }
        echo(c, 2);
    }

    private Long echo() {
        System.out.println(" *** Normal echo()");
        return 0L;
    }

    private <V> List<V> echo(Continuation c, V x) {
        System.out.println(" *** Instrum echo(): start - arg x = " + x);
        c.suspend();
        System.out.println(" *** Instrum echo(): end - arg x = " + x);
        final List<V> res = new ArrayList<>();
        res.add(x);
        return res;
    }

}
