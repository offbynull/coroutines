import java.util.LinkedList;

import com.offbynull.coroutines.user.Continuation;
import com.offbynull.coroutines.user.Coroutine;

public class MonitorInvokeTest implements Coroutine {
    private LinkedList<String> state;
    private Object mon1;
    private Object mon2;
    private Object mon3;

    public MonitorInvokeTest(LinkedList<String> state, Object mon1, Object mon2, Object mon3) {
	this.state = state;
	this.mon1 = mon1;
	this.mon2 = mon2;
	this.mon3 = mon3;
    }

    public void run(Continuation c) {
	synchronized (mon1) {
	    state.addLast("mon1");
	    innerLocks(c);
	}
	state.removeLastOccurrence("mon1");
	c.suspend();
    }

    private void innerLocks(Continuation c) {
	synchronized (mon2) {
	    state.addLast("mon2");
	    synchronized (mon3) {
		state.addLast("mon3");
		synchronized (mon1) {
		    state.addLast("mon1");
		    c.suspend();
		}
		state.removeLastOccurrence("mon1");
		c.suspend();
	    }
	    state.removeLastOccurrence("mon3");
	    c.suspend();
	}
	state.removeLastOccurrence("mon2");
	c.suspend();
    }
}
