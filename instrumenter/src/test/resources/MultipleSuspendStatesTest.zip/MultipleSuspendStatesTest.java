import com.offbynull.coroutines.user.Continuation;
import com.offbynull.coroutines.user.Coroutine;

public class MultipleSuspendStatesTest implements Coroutine {
    private StringBuilder builder;
    
    public MultipleSuspendStatesTest(StringBuilder builder) {
        this.builder = builder;
    }

    public void run(Continuation c) {
        // What's the point of this test???
        //
        // 1. var2 is uninitialized at the first suspend, but is initialized at the second suspend.
        // 2. After the second suspend, the operand stack will start carrying a couple of extra ints on it when pausing, where as before it had only Objects.
        //
        // We do this because we want to make sure our generators that save/load state aren't crapping out when they see uninitialized locals or different/missing/new types on the operand stack
        String var1 = "a";
        c.suspend();     
        
        builder.append(var1);
        int var2 = 'b';
        c.suspend();
        
        long var3 = suspendHelper(c) + builder.append((char) var2).toString().length() + suspendHelper(c);
        System.out.println(var3);
    }
    
    public int suspendHelper(Continuation c) {
        c.suspend();
        return 0;
    }
}
