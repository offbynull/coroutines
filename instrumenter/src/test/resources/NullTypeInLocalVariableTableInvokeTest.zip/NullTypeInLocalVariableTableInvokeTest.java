import com.offbynull.coroutines.user.Continuation;
import com.offbynull.coroutines.user.Coroutine;

public class NullTypeInLocalVariableTableInvokeTest implements Coroutine {
    private StringBuilder builder;
    
    public NullTypeInLocalVariableTableInvokeTest(StringBuilder builder) {
	this.builder = builder;
    }

    public void run(Continuation c) {
	builder.append("started\n");
	for (int i = 0; i < 10; i++) {
	    echo(c, i);
	}
    }

    private void echo(Continuation c, int x) {
	Object obj = null;
	builder.append(x).append('\n');
	c.suspend();
	System.out.println(obj);
    }
}
