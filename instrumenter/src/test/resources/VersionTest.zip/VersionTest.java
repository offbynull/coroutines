
import com.offbynull.coroutines.user.Continuation;
import com.offbynull.coroutines.user.Coroutine;

public class VersionTest implements Coroutine {

    public String name = VersionTest.class.getSimpleName();
    public StringBuilder sb = new StringBuilder();

    public void run(Continuation c) {
        byte _b = 1;
        char _c = 2;
        int _i = 3;
        float _f = 4.0f;
        long _l = 5L;
        double _d = 6.0;
        String _s = "src";

        sb.append("pre_src:")
                .append(' ').append(name)
                .append(' ').append(_b)
                .append(' ').append(_c)
                .append(' ').append(_i)
                .append(' ').append(_f)
                .append(' ').append(_l)
                .append(' ').append(_d)
                .append(' ').append(_s)
                .append('\n');

        c.suspend();

        sb.append("post_src:")
                .append(' ').append(name)
                .append(' ').append(_b)
                .append(' ').append(_c)
                .append(' ').append(_i)
                .append(' ').append(_f)
                .append(' ').append(_l)
                .append(' ').append(_d)
                .append(' ').append(_s)
                .append('\n');
    }

    public static void coroutinesRestoreRun_jTCfkejgbi6UrYGfnVwxg(Object[] container) {
        Object var_this = ((Object[]) container[4])[0]; // idx0 Lcoroutines_maven_test/VersionTest;
        Object var_c = ((Object[]) container[4])[1]; // idx1 Lcom/offbynull/coroutines/user/Continuation;
        int var__b = ((int[]) container[0])[0]; // idx2
        int var__c = ((int[]) container[0])[1]; // idx3
        int var__i = ((int[]) container[0])[2]; // idx4
        float var__f = ((float[]) container[1])[0]; // idx5
        long var__l = ((long[]) container[2])[0]; // idx6
        double var__d = ((double[]) container[3])[0]; // idx8
        Object var__s = ((Object[]) container[4])[2]; // idx10 Ljava/lang/String;
        Object operand_0 = ((Object[]) container[9])[0]; // idx0 Lcom/offbynull/coroutines/user/Continuation;

        // how to modify state on restore 
        var__b = -1;
        var__c = -2;
        var__i = -3;
        var__f = -4.0f;
        var__l = -05L;
        var__d = -6.0;
        var__s = "dst";

        ((Object[]) container[4])[0] = var_this; // idx0 Lcoroutines_maven_test/VersionTest;
        ((Object[]) container[4])[1] = var_c; // idx1 Lcom/offbynull/coroutines/user/Continuation;
        ((int[]) container[0])[0] = var__b; // idx2
        ((int[]) container[0])[1] = var__c; // idx3
        ((int[]) container[0])[2] = var__i; // idx4
        ((float[]) container[1])[0] = var__f; // idx5
        ((long[]) container[2])[0] = var__l; // idx6
        ((double[]) container[3])[0] = var__d; // idx8
        ((Object[]) container[4])[2] = var__s; // idx10 Ljava/lang/String;
        ((Object[]) container[9])[0] = operand_0; // idx0 Lcom/offbynull/coroutines/user/Continuation;
    }
}
