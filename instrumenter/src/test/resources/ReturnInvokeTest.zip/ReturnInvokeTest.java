import com.offbynull.coroutines.user.Continuation;
import com.offbynull.coroutines.user.Coroutine;

public class ReturnInvokeTest implements Coroutine {
    private StringBuilder builder;
    
    public ReturnInvokeTest(StringBuilder builder) {
	this.builder = builder;
    }

    public void run(Continuation c) {
	builder.append("started\n");
	int i = 0;
	while (echo(c, i)) {
	    i++;
	}
    }

    private boolean echo(Continuation c, int x) {
	builder.append(x).append('\n');
	c.suspend();
	return x < 9;
    }
}
