import com.offbynull.coroutines.user.Continuation;
import com.offbynull.coroutines.user.Coroutine;

public class ReturnInvokeTest implements Coroutine {
    private StringBuilder builder;
    
    public ReturnInvokeTest(StringBuilder builder) {
	this.builder = builder;
    }

    public void run(Continuation c) {
	builder.append("started\n");
	int i = 0;
	while (true) {
	    int res = echo(c, i);
	    if (res != (5 + i + (i * i))) {
		throw new RuntimeException("test failed!");
	    }
	    i++;
	    if (i == 10) {
		break;
	    }
	}
    }

    private int echo(Continuation c, int x) {
	return 5 + echoInner(c, x) + x;
    }
    
    private int echoInner(Continuation c, int x) {
	builder.append(x).append('\n');
	c.suspend();
	return x * x;
    }
}
