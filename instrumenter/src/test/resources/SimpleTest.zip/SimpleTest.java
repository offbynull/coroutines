import com.offbynull.coroutines.user.Continuation;

public class SimpleTest {
    private StringBuilder builder;
    
    public SimpleTest(StringBuilder builder) {
	this.builder = builder;
    }

    public void run(Continuation c) {
	builder.append("started\n");
	for (int i = 0; i < 10; i++) {
	    echo(c, i);
	}
    }

    private void echo(Continuation c, int x) {
	builder.append(x).append('\n');
	c.suspend();
    }
}
