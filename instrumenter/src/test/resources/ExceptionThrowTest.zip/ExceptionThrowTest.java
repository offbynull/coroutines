import com.offbynull.coroutines.user.Continuation;
import com.offbynull.coroutines.user.Coroutine;

public class ExceptionThrowTest implements Coroutine {
    private StringBuilder builder;
    
    public ExceptionThrowTest(StringBuilder builder) {
	this.builder = builder;
    }

    public void run(Continuation c) {
	builder.append("started\n");
	for (int i = 0; i < 10; i++) {
	    echo(c, i);
	}
    }

    private void echo(Continuation c, int x) {
	builder.append(x).append('\n');
	if (x == 5) {
	    throw new RuntimeException("Hit 5!");
	} else {
	    c.suspend();
	}
    }
}
