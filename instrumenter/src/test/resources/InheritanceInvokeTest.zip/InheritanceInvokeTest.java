import com.offbynull.coroutines.user.Continuation;
import com.offbynull.coroutines.user.Coroutine;

public class InheritanceInvokeTest implements Coroutine {
    private StringBuilder builder;
    
    public InheritanceInvokeTest(StringBuilder builder) {
	this.builder = builder;
    }

    public void run(Continuation c) {
	builder.append("started\n");
	new Class9().run(c);
    }

    private class Class0 {
	public void run(Continuation c) {
	    builder.append(0).append('\n');
	    c.suspend();
	}
    }
    
    private class Class1 extends Class0 {
	public void run(Continuation c) {
	    super.run(c);
	    builder.append(1).append('\n');
	    c.suspend();
	}
    }
    
    private class Class2 extends Class1 {
	public void run(Continuation c) {
	    super.run(c);
	    builder.append(2).append('\n');
	    c.suspend();
	}
    }
    
    private class Class3 extends Class2 {
	public void run(Continuation c) {
	    super.run(c);
	    builder.append(3).append('\n');
	    c.suspend();
	}
    }
    
    private class Class4 extends Class3 {
	public void run(Continuation c) {
	    super.run(c);
	    builder.append(4).append('\n');
	    c.suspend();
	}
    }
    
    private class Class5 extends Class4 {
	public void run(Continuation c) {
	    super.run(c);
	    builder.append(5).append('\n');
	    c.suspend();
	}
    }
    
    private class Class6 extends Class5 {
	public void run(Continuation c) {
	    super.run(c);
	    builder.append(6).append('\n');
	    c.suspend();
	}
    }
    
    private class Class7 extends Class6 {
	public void run(Continuation c) {
	    super.run(c);
	    builder.append(7).append('\n');
	    c.suspend();
	}
    }
    
    private class Class8 extends Class7 {
	public void run(Continuation c) {
	    super.run(c);
	    builder.append(8).append('\n');
	    c.suspend();
	}
    }
    
    private class Class9 extends Class8 {
	public void run(Continuation c) {
	    super.run(c);
	    builder.append(9).append('\n');
	    c.suspend();
	}
    }
}
