import com.offbynull.coroutines.user.Continuation;
import com.offbynull.coroutines.user.Coroutine;

public class UninitializedVariableInvokeTest implements Coroutine {
    private StringBuilder builder;

    public UninitializedVariableInvokeTest(StringBuilder builder) {
	this.builder = builder;
    }

    public void run(Continuation c) {
	c.setContext(new Context());
	
	System.out.println("1");
	Context context = (Context) c.getContext();

	Endpoint selfEp = (Endpoint) context.getMessage();
	c.suspend();
	System.out.println("2");
	Endpoint dstEp = (Endpoint) context.getMessage();

	for (int i = 0; i < 10; i++) {
	    dstEp.send(selfEp, i);
	    System.out.println("3");
	    c.suspend();
	    System.out.println("i currently is " + i);
	    // Validate.isTrue(context.getMessage().equals(i));
	    // try {
	    // latch.countDown();
	    // } catch (Exception e) {
	    // System.out.println("lolwat?");
	    // }
	    // System.out.println("5");
	}
    }

    private static final class Endpoint {

	public void send(Endpoint selfEp, int i) {
	    // TODO Auto-generated method stub

	}

    }

    private static final class Context {

	public Endpoint getMessage() {
	    // TODO Auto-generated method stub
	    return new Endpoint();
	}

    }
}
