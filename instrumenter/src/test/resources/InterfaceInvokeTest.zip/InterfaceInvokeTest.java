import com.offbynull.coroutines.user.Continuation;
import com.offbynull.coroutines.user.Coroutine;

public class InterfaceInvokeTest implements Coroutine {
    private StringBuilder builder;
    private Echoer echoer = new EchoerImplementation();
    
    public InterfaceInvokeTest(StringBuilder builder) {
	this.builder = builder;
    }

    public void run(Continuation c) {
	builder.append("started\n");
	for (int i = 0; i < 10; i++) {
	    echoer.echo(c, i);
	}
    }
    
    public interface Echoer {
	void echo(Continuation c, int x);
    }
    
    public class EchoerImplementation implements Echoer {

	@Override
	public void echo(Continuation c, int x) {
            builder.append(x).append('\n');
            c.suspend();	    
	}
	
    }
}
