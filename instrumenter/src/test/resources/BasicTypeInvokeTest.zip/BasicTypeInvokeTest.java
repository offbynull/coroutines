import com.offbynull.coroutines.user.Continuation;
import com.offbynull.coroutines.user.Coroutine;

public class BasicTypeInvokeTest implements Coroutine {
    private StringBuilder builder;
    
    public BasicTypeInvokeTest(StringBuilder builder) {
	this.builder = builder;
    }

    public void run(Continuation c) {
	builder.append("started\n");
	for (int i = 0; i < 10; i++) {
	    echo(c, (byte) i, (char) i, (short) i, i, (long) i, (float) i, (double) i, i);
	}
    }

    private void echo(Continuation c, byte b, char ch, short s, int i, long l, float f, double d, Object o) {
	builder.append(i).append('\n');
	System.out.print(b);
	System.out.print(ch);
	System.out.print(s);
	System.out.print(i);
	System.out.print(l);
	System.out.print(f);
	System.out.print(d);
	System.out.println(o);
	c.suspend();
	System.out.print(b);
	System.out.print(ch);
	System.out.print(s);
	System.out.print(i);
	System.out.print(l);
	System.out.print(f);
	System.out.print(d);
	System.out.println(o);
    }
}
